# Simple Plagiarism Detection System — DAA Mini Project

A beginner-friendly Python + Streamlit mini-project demonstrating:
- Naïve String Matching
- KMP (Knuth–Morris–Pratt)
- Rabin–Karp
- Exact sentence matching between two documents
- A simple matching-text coverage estimate
- Runtime comparison table and bar chart
- Time/space complexity summary

## Requirements
- Python 3.9 or newer
- Internet connection for the first installation of packages

## Run on Windows
1. Extract this ZIP file.
2. Open the extracted folder.
3. Click the address bar in File Explorer, type `cmd`, and press Enter.
4. Run these commands:

```bash
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

If `py` does not work, try `python` instead:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

5. A browser tab will open with the project. If it does not, copy the local URL shown in the terminal (usually `http://localhost:8501`) into your browser.
6. Click **Compare Documents** to run the included example.

## Demo example
Document A:
> Data structures help organize information. Efficient algorithms save time. String matching is useful for text comparison.

Document B:
> Efficient algorithms save time. String matching is useful for text comparison. Python is easy to learn.

Expected result: two identical sentences should be found. Exact timing varies by computer.

## What to say during the demo
- Naïve checks the pattern at each possible position.
- KMP uses an LPS (Longest Proper Prefix which is also Suffix) array to avoid unnecessary comparisons.
- Rabin–Karp uses a rolling hash and checks the actual text if hashes match.
- All algorithms search the same patterns in the same text, then the program measures elapsed time.
- Short inputs can make timing differences tiny, so the chart is a demonstration, not proof that one algorithm is always faster.

## Important limitation
This educational prototype matches exact full sentences only for the displayed coverage estimate. It does not detect paraphrasing, translated content, or all forms of plagiarism. The percentage is a matching-text estimate, not proof of plagiarism.
