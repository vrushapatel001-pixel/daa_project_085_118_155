import streamlit as st
import time
import re
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Simple Plagiarism Checker", page_icon="🔎", layout="wide")

# -------------------- DAA ALGORITHMS --------------------
def naive_search(text, pattern):
    """Return all starting positions where pattern occurs in text."""
    positions = []
    n, m = len(text), len(pattern)
    if m == 0 or m > n:
        return positions

    for i in range(n - m + 1):
        j = 0
        while j < m and text[i + j] == pattern[j]:
            j += 1
        if j == m:
            positions.append(i)
    return positions


def build_lps(pattern):
    """Build the Longest Proper Prefix which is also Suffix array for KMP."""
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        elif length != 0:
            length = lps[length - 1]
        else:
            lps[i] = 0
            i += 1

    return lps


def kmp_search(text, pattern):
    """Return all starting positions where pattern occurs in text using KMP."""
    positions = []
    n, m = len(text), len(pattern)
    if m == 0 or m > n:
        return positions

    lps = build_lps(pattern)
    i = j = 0

    while i < n:
        if text[i] == pattern[j]:
            i += 1
            j += 1

            if j == m:
                positions.append(i - j)
                j = lps[j - 1]
        else:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1

    return positions


def rabin_karp_search(text, pattern):
    """Return all starting positions where pattern occurs using rolling hash."""
    positions = []
    n, m = len(text), len(pattern)
    if m == 0 or m > n:
        return positions

    base = 256
    prime = 101
    pattern_hash = 0
    window_hash = 0
    high_power = pow(base, m - 1, prime)

    for i in range(m):
        pattern_hash = (base * pattern_hash + ord(pattern[i])) % prime
        window_hash = (base * window_hash + ord(text[i])) % prime

    for start in range(n - m + 1):
        # Always verify characters when hashes match (collision safety).
        if pattern_hash == window_hash and text[start:start + m] == pattern:
            positions.append(start)

        if start < n - m:
            window_hash = (
                base * (window_hash - ord(text[start]) * high_power)
                + ord(text[start + m])
            ) % prime

    return positions


ALGORITHMS = {
    "Naïve": naive_search,
    "KMP": kmp_search,
    "Rabin–Karp": rabin_karp_search,
}

# -------------------- SIMPLE USER INTERFACE --------------------
st.title("🔎 Simple Plagiarism Detection System")
st.caption("DAA Mini Project | Naïve String Matching • KMP • Rabin–Karp")
st.write(
    "Paste two short documents below. This demo finds exact matching sentences "
    "and compares how long each algorithm takes."
)

sample_a = (
    "Data structures help organize information. "
    "Efficient algorithms save time. "
    "String matching is useful for text comparison."
)
sample_b = (
    "Efficient algorithms save time. "
    "String matching is useful for text comparison. "
    "Python is easy to learn."
)

if "doc_a" not in st.session_state:
    st.session_state.doc_a = sample_a
if "doc_b" not in st.session_state:
    st.session_state.doc_b = sample_b

left, right = st.columns(2)
with left:
    st.subheader("Document A (Original)")
    doc_a = st.text_area("Enter Document A", key="doc_a", height=170, label_visibility="collapsed")
with right:
    st.subheader("Document B (To Check)")
    doc_b = st.text_area("Enter Document B", key="doc_b", height=170, label_visibility="collapsed")

col1, col2 = st.columns([1, 3])
with col1:
    run = st.button("Compare Documents", type="primary", use_container_width=True)
with col2:
    st.caption("Tip: Click Compare Documents with the sample text to see a working example.")

def clean_text(text):
    # Lowercase and standardize whitespace for a simple, case-insensitive demo.
    return re.sub(r"\s+", " ", text.lower()).strip()

def sentences(text):
    return [part.strip() for part in re.split(r"[.!?]+", text) if part.strip()]

def find_unique_matching_sentences(a, b):
    a_sentences = sentences(a)
    b_sentences = sentences(b)
    a_set = set(a_sentences)
    # Preserve order and avoid counting the same matching sentence twice.
    return list(dict.fromkeys(sentence for sentence in b_sentences if sentence in a_set))

if run:
    normalized_a = clean_text(doc_a)
    normalized_b = clean_text(doc_b)

    if not normalized_a or not normalized_b:
        st.warning("Please enter text in both documents.")
        st.stop()

    matches = find_unique_matching_sentences(normalized_a, normalized_b)
    matched_chars = sum(len(sentence) for sentence in matches)
    coverage = (matched_chars / max(1, len(normalized_b))) * 100

    st.divider()
    st.subheader("1. Matching Result")
    metric1, metric2, metric3 = st.columns(3)
    metric1.metric("Matching-text coverage", f"{coverage:.1f}%")
    metric2.metric("Exact matching sentences", len(matches))
    metric3.metric("Document B characters", len(normalized_b))

    if matches:
        st.success("Matching sentences found:")
        for sentence in matches:
            st.markdown(f"- “{sentence}”")
    else:
        st.info("No identical full sentences were found. This simple demo checks exact sentence matches.")

    st.caption(
        "Coverage is an educational estimate based on exact matching sentences, not proof of plagiarism. "
        "Partial sentence matches are not included in this percentage."
    )

    st.divider()
    st.subheader("2. Algorithm Performance Comparison")
    st.write(
        "For a fair comparison, each algorithm searches for the same matching sentences from Document B "
        "inside Document A. Timings are measured on this computer and may be very small for short text."
    )

    # Use the same patterns and text for each algorithm. Repeat the work to make timing less noisy.
    patterns = list(dict.fromkeys(sentences(normalized_b)))
    benchmark_text = normalized_a
    rows = []
    result_positions = {}

    for name, algorithm in ALGORITHMS.items():
        start_time = time.perf_counter()
        found_total = 0
        positions_for_algorithm = {}
        for pattern in patterns:
            positions = algorithm(benchmark_text, pattern)
            found_total += len(positions)
            positions_for_algorithm[pattern] = positions
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        rows.append({
            "Algorithm": name,
            "Patterns found": found_total,
            "Execution time (ms)": elapsed_ms,
        })
        result_positions[name] = positions_for_algorithm

    results_df = pd.DataFrame(rows)
    st.dataframe(
        results_df.style.format({"Execution time (ms)": "{:.6f}"}),
        use_container_width=True,
        hide_index=True,
    )

    chart_df = results_df.set_index("Algorithm")[["Execution time (ms)"]]
    fig, ax = plt.subplots()
    chart_df.plot(kind="bar", ax=ax, legend=False)
    ax.set_ylabel("Execution time (milliseconds)")
    ax.set_xlabel("Algorithm")
    ax.set_title("Execution Time Comparison")
    ax.tick_params(axis="x", rotation=0)
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

    st.subheader("3. DAA Complexity Summary")
    complexity_df = pd.DataFrame([
        {"Algorithm": "Naïve", "Best/typical note": "Simple to understand", "Worst-case time": "O(n × m)", "Extra space": "O(1)"},
        {"Algorithm": "KMP", "Best/typical note": "Uses an LPS array to avoid rechecking", "Worst-case time": "O(n + m)", "Extra space": "O(m)"},
        {"Algorithm": "Rabin–Karp", "Best/typical note": "Uses rolling hash; verifies matching hashes", "Expected time": "O(n + m)", "Extra space": "O(1) extra (excluding output)"},
    ])
    st.dataframe(complexity_df, use_container_width=True, hide_index=True)

    st.info(
        "For very short inputs, execution-time differences may not be meaningful. "
        "Use longer documents or repeat the experiment for a more reliable performance study."
    )

st.divider()
with st.expander("How to explain this project in your presentation"):
    st.markdown(
        """
        1. The user enters two documents.
        2. The program converts text to lowercase and standardizes whitespace.
        3. It splits text into sentences and finds identical sentences in both documents.
        4. Naïve, KMP, and Rabin–Karp each search for the same sentence patterns in Document A.
        5. The dashboard compares their measured execution times and displays their complexity.

        **Limitation:** This is a small educational prototype. It detects exact matching sentences, not paraphrased
        or translated text, and a match alone does not prove plagiarism.
        """
    )
